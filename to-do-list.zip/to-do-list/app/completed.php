<?php
require '../db_conn.php';
session_start();

// Redirect jika belum login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/loginform.php");
    exit();
}

// Ambil data tugas yang selesai
try {
    $user_id = $_SESSION['user_id'];
    $query = "SELECT id, task_name, due_date, updated_at 
              FROM tasks 
              WHERE user_id = :user_id AND status = 'Done'
              ORDER BY updated_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $completed_tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p class='text-danger'>Unable to fetch completed tasks. Please try again later.</p>";
    error_log("Error fetching completed tasks: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Completed Tasks</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        main {
            flex: 1;
        }

        footer {
            background: linear-gradient(to right, #357abd, #4a90e2);
            color: #ffffff;
            text-align: center;
            padding: 20px 0;
        }

        footer small {
            color: #d1e3f8;
            display: block;
            margin-top: 5px;
        }

        footer p {
            margin: 0;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <!-- Include Navbar -->
    <?php include '../navbar.php'; ?>

    <main class="container py-4">
        <h1 class="text-success">Completed Tasks</h1>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Task</th>
                        <th>Due Date</th>
                        <th>Completed At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($completed_tasks)): ?>
                        <?php foreach ($completed_tasks as $task): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($task['task_name'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($task['due_date'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo date('d M Y, H:i', strtotime($task['updated_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="text-center">No completed tasks found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Tickle Task Website. All rights reserved.</p>
        <small>Tickle Task with by Kelompok 6.</small>
    </footer>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>

</html>