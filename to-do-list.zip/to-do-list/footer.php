<footer class="footer bg-dark text-white text-center py-3 mt-5">
    <div class="container">
        <p class="mb-0">&copy; 2024 To-Do List. All rights reserved.</p>
        <small>Tickle Task by Kelompok 6.</small>
    </div>
</footer>