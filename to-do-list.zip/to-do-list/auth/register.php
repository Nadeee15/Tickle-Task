<?php
session_start();
require '../db_conn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Validasi input kosong
    if (empty($email) || empty($username) || empty($password)) {
        header("Location: ../signupform.php?error=Please fill in all fields");
        exit();
    }

    // Validasi format email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: ../signupform.php?error=Invalid email format");
        exit();
    }

    // Cek apakah email atau username sudah terdaftar
    try {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $username]);
        if ($stmt->rowCount() > 0) {
            header("Location: ../signupform.php?error=Email or Username already exists");
            exit();
        }

        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Simpan pengguna baru ke database
        $stmt = $conn->prepare("INSERT INTO users (email, username, password) VALUES (?, ?, ?)");
        if ($stmt->execute([$email, $username, $hashed_password])) {
            header("Location: ../loginform.php?success=Account created successfully");
            exit();
        } else {
            header("Location: ../signupform.php?error=Failed to create account");
            exit();
        }
    } catch (PDOException $e) {
        // Tangani error database
        header("Location: ../signupform.php?error=Database error: " . $e->getMessage());
        exit();
    }
} else {
    // Jika bukan POST, redirect ke form signup
    header("Location: ../signupform.php");
    exit();
}
?>