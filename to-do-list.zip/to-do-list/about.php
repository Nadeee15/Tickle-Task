<?php
require 'db_conn.php';
session_start();

// Redirect jika belum login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/loginform.php");
    exit();
}

// Ambil nama pengguna
$username = htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f9fa;
        }

        main {
            max-width: 800px;
            margin: 0 auto;
            text-align: center;
            line-height: 1.8;
            padding: 20px;
        }

        h1,
        h2 {
            color: #2c3e50;
            font-weight: bold;
        }

        p,
        li {
            color: #555;
        }

        ol {
            margin: 20px auto;
            padding: 0;
            text-align: center;
            list-style-position: inside;
            display: inline-block;
            text-align: left;
        }

        footer {
            background: linear-gradient(to right, #357abd, #4a90e2);
            color: white;
            text-align: center;
            padding: 10px 0;
            margin-top: 30px;
            box-shadow: 0 -2px 4px rgba(0, 0, 0, 0.1);
        }

        footer p {
            margin: 0;
            font-weight: bold;
        }

        footer small {
            display: block;
            font-size: 12px;
            color: #d1e3f8;
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <!-- Include Navbar -->
    <?php include 'navbar.php'; ?>

    <!-- Main Content -->
    <main class="container py-5">
        <section class="mt-5">
            <h2 class="fw-bold">Tentang</h2>
            <p>
                Tickle Task adalah aplikasi sederhana yang membantu Anda mengelola dan menyelesaikan tugas dengan lebih
                teratur dan efisien. Dengan antarmuka yang mudah digunakan, Anda dapat mengatur dan melacak tugas-tugas
                Anda dengan mudah, tanpa rasa bingung. Fokus pada yang penting dan capai tujuan Anda dengan cara yang
                lebih terstruktur.
            </p>
        </section>
        <section class="mt-5">
            <h2 class="fw-bold">Visi</h2>
            <p>
                Menjadi website utama untuk pengelolaan tugas dan kolaborasi yang efisien, meningkatkan produktivitas
                dan fleksibilitas, serta memudahkan pengambilan keputusan yang cerdas.
            </p>
        </section>
        <section class="mt-5">
            <h2 class="fw-bold">Misi</h2>
            <ol>
                <li>Mempermudah Pengelolaan Tugas</li>
                <li>Menyediakan Pengingat Otomatis</li>
                <li>Meningkatkan Produktivitas</li>
                <li>Mendukung Kolaborasi</li>
                <li>Memberikan Aksesibilitas Lintas Perangkat</li>
                <li>Mempermudah Pengambilan Keputusan</li>
                <li>Mendukung Fleksibilitas dan Kustomisasi</li>
                <li>Mengurangi Beban Pikiran</li>
            </ol>
        </section>

        <section class="container text-center py-5">
            <h2 class="fw-bold">Present By</h2>
            <div class="row mt-4">
                <div class="col-md-3">
                    <img src="img/anggi.jpg" alt="Person 1" class="img-fluid rounded shadow"
                        style="width: 150px; height: 200px; object-fit: cover;">
                    <p class="mt-2">Anggi Permata Sari</p>
                </div>
                <div class="col-md-3">
                    <img src="img/aul.jpg" alt="Person 2" class="img-fluid rounded shadow"
                        style="width: 150px; height: 200px; object-fit: cover;">
                    <p class="mt-2">Aulia Rahmi Sahkira</p>
                </div>
                <div class="col-md-3">
                    <img src="img/erlin.png" alt="Person 3" class="img-fluid rounded shadow"
                        style="width: 150px; height: 200px; object-fit: cover;">
                    <p class="mt-2">Erlin Sari Ramadhani</p>
                </div>
                <div class="col-md-3">
                    <img src="img/nadjwa.jpg" alt="Person 4" class="img-fluid rounded shadow"
                        style="width: 150px; height: 200px; object-fit: cover;">
                    <p class="mt-2">Nadjwa Tasya Safira</p>
                </div>
            </div>
        </section>

    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Tickle Task Website. All rights reserved.</p>
        <small>Tickle Task with by Kelompok 6.</small>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>